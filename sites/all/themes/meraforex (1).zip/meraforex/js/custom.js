(function($){
	
	//Sticky Header
	$(window).scroll(function(){
	scroll = $(this).scrollTop();
	if(scroll >= 100){
		$("header").addClass("sticky");
		//$(".logo").stop(true).animate({ width : "80%"},500,"linear");
	}else{
		$("header").removeClass("sticky");
		//$(".logo").stop(true).animate({ width : "100%"},500,"linear");
	}
	});
	
	//Loader class
	jQuery(window).load(function () {
		jQuery(".loader-cont").fadeOut(3000);
	});
	
}(jQuery));


(function($){
	
	$(".payment").click(function(){
		alert("test");
  });
	
	
	}(jQuery));
